﻿using CPF;
using CPF.Controls;
using CPF.Drawing;
using CPF.Input;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using 蓝图重制版.BluePrint.INode;
using 蓝图重制版.BluePrint.Node;

namespace 蓝图重制版.BluePrint
{
    public class BParent : Control
    {
        public void SetContext(Context context) { 

        }
        protected override void OnRender(DrawingContext dc)
        {
            var rect = new Rect(ActualSize);
            base.OnRender(dc);

            using (var brush = XPathColor.CreateBrush(rect, Root.RenderScaling))
            {
                using (var brush1 = YPathColor.CreateBrush(rect, Root.RenderScaling))
                {
                    //dc.FillRectangle(brush, rect);

                    PathGeometry XPath = new PathGeometry();
                    PathGeometry YPath = new PathGeometry();
                    for (int i = 0; i < rect.Height; i++)
                    {
                        if (i % 12 == 0)
                        {
                            XPath.BeginFigure(0, i);
                            XPath.LineTo(rect.Width, i);
                        }
                        if (i % 84 == 0)
                        {
                            YPath.BeginFigure(0, i);
                            YPath.LineTo(rect.Width, i);
                        }
                    }

                    for (int i = 0; i < rect.Width; i++)
                    {
                        if (i % 12 == 0)
                        {
                            XPath.BeginFigure(i, 0);
                            XPath.LineTo(i, rect.Width);
                        }
                        if (i % 84 == 0)
                        {
                            YPath.BeginFigure(i, 0);
                            YPath.LineTo(i, rect.Width);
                        }
                    }

                    dc.DrawPath(brush, "1", XPath);
                    dc.DrawPath(brush1, "1", YPath);
                }
            }
        }

        private ViewFill XPathColor = Color.FromRgba(188, 191, 188, 50);
        private ViewFill YPathColor = Color.FromRgba(0, 0, 0, 150);


        public BluePrint bluePrint;
        //public Panel panel;
        protected override void InitializeComponent()
        {
            //Instances.Add(this);
            //模板定义
            ClipToBounds = true;
            base.InitializeComponent();
            Background = Color.FromRgb(39, 39, 39);
            bluePrint = new BluePrint
            {
                MarginLeft = 0f,
                MarginTop = 0f,
                //Width = "100%",
                //Height = "100%",
                Tag = 1f,
                RenderTransformOrigin = new PointField(0, 0),
            };
            //panel = new Panel
            //{
            //    MarginLeft = 0f,
            //    MarginTop = 0f,
            //    Children = { bluePrint }
            //};
            Children.Add(bluePrint);
            //添加拖动节点
            MouseJoin = new MouseJoin(this, IJoinControl.NodePosition.Left) {
                MarginLeft = 0f,
                MarginTop = 0f,
                Width = 1f,
                Height = 1f
            };
            bluePrint.AddChildren(MouseJoin);
            //
            //添加默认拖动显示线条
            bP_Line = new BP_Line
            {
                MarginLeft = 0f,
                MarginTop = 0f,
            };

            
            //bP_Line.Size = new SizeField(1,1);
            //ClearState();
            bluePrint.AddLineChildren(bP_Line);
            //ClearState();

        }

        float scale = 1;
        protected override void OnMouseWheel(MouseWheelEventArgs e)
        {
            var p = e.MouseDevice.GetPosition(bluePrint);
            Matrix matrix = Matrix.Identity;
            if (bluePrint.RenderTransform is MatrixTransform transform)
            {
                matrix = transform.Value;
            }
            if (e.Delta.Y < 0)
            {
                scale *= 0.8f;
                if (scale < 0.01)
                {
                    scale /= 0.8f;
                }
                else
                {
                    matrix.ScaleAtPrepend(0.8f, 0.8f, p.X, p.Y);
                }
            }
            else
            {
                scale /= 0.8f;
                matrix.ScaleAtPrepend(1 / 0.8f, 1 / 0.8f, p.X, p.Y);
            }
            bluePrint.RenderTransform = new MatrixTransform(matrix);
            base.OnMouseWheel(e);
        }
        Point? mousePos;
        protected override void OnMouseDown(MouseButtonEventArgs e)
        {
            base.OnMouseDown(e);
            if (e.MouseButton == MouseButton.Right)
            {
                mousePos = e.Location / scale;
                CaptureMouse();
            }

        }
        protected override void OnMouseUp(MouseButtonEventArgs e)
        {
            base.OnMouseUp(e);
            if (e.MouseButton == MouseButton.Right)
            {
                mousePos = null;
                ReleaseMouseCapture();
            }
            
        }
        /// <summary>
        /// 清空当前拖放状态
        /// </summary>
        public void ClearState() {
            IsMouseJoin = false;
            bP_Line.SetJoin(null, null);
            bP_Line.Width = 0f;
            bP_Line.Height = 0f;
        }
        /// <summary>
        /// 用于鼠标拖动的接口，本身只是为了拖动 
        /// </summary>
        public IJoinControl MouseJoin;// = new MouseJoin(this,IJoinControl.NodePosition.Left);
        /// <summary>
        /// 用于模拟拖动的线，不参与流程
        /// </summary>
        public BP_Line bP_Line;
        /// <summary>
        /// 上一个选中的接口
        /// </summary>
        public IJoinControl ParentJoin = null;
        /// <summary>
        /// 设置鼠标状态
        /// </summary>
        /// <param name="State"></param>
        public void SetMouseState(IJoinControl State) {
            //IsMouseJoin = false;
            if (ParentJoin == null)
            {
                ParentJoin = State;
                //MouseJoin.Margin = State.Margin;
                if (ParentJoin.GetDir() == IJoinControl.NodePosition.Left)
                {
                    MouseJoin.SetDir(IJoinControl.NodePosition.right);
                    bP_Line.SetJoin(MouseJoin, ParentJoin);
                }
                if (ParentJoin.GetDir() == IJoinControl.NodePosition.right)
                {
                    MouseJoin.SetDir(IJoinControl.NodePosition.Left);
                    bP_Line.SetJoin(ParentJoin, MouseJoin);
                }
                IsMouseJoin = true;
            }
            else {
                //输入输出一样或者父元素一样全部不可连接
                if (ParentJoin.GetDir() == State.GetDir() ||
                    ParentJoin.Parent == State.Parent)
                {
                    ClearState();
                }
                else {
                    //现在就可以初始化线条用于连接
                    //再判断一下两个节点是否已经有线条了

                    IJoinControl a,b;
                    
                    if (ParentJoin.GetDir() == IJoinControl.NodePosition.Left)
                    {
                        a = State;
                        b = ParentJoin;
                    }
                    else {
                        a = ParentJoin;
                        b = State;
                        //bP_Line1.SetJoin(ParentJoin, State);
                    }
                    if (!bluePrint.FildLine(a, b))
                    {
                        var bP_Line1 = new BP_Line
                        {
                            MarginLeft = 0f,
                            MarginTop = 0f,
                            Width = 1f,
                            Height = 1f
                        };
                        bP_Line1.SetJoin(a, b);
                        bluePrint.AddLineChildren(bP_Line1);
                    }
                    else { 
                        //已经连过了
                    }
                    ClearState(); 
                }
                ParentJoin = null;
            }
        }
        public bool IsMouseJoin = false;
        protected override void OnMouseMove(MouseEventArgs e)
        {
            
            base.OnMouseMove(e);
            if (IsMouseJoin)
            {
                Debug.WriteLine($"e.Location:{e.Location}");
                MouseJoin.MarginLeft = e.Location.X;
                MouseJoin.MarginTop = e.Location.Y;
                //Debug.WriteLine($"e.Location11:{MouseJoin.MarginLeft},{MouseJoin.MarginTop}");


            }
            if (mousePos.HasValue)
            {
                //bluePrint.MarginLeft
                var aa = e.Location.X - bluePrint.MarginLeft.Value / scale;
                var p = e.Location / scale;
                var a = p - mousePos.Value;
                Matrix matrix = Matrix.Identity;
                if (bluePrint.RenderTransform is MatrixTransform transform)
                {
                    matrix = transform.Value;
                }
                
                matrix.TranslatePrepend(a.X, a.Y);
                System.Diagnostics.Debug.WriteLine(a);
                bluePrint.RenderTransform = new MatrixTransform(matrix);
                mousePos = p;
            }
        }

    }
}
