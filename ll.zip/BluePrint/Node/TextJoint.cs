﻿using CPF;
using CPF.Controls;
using CPF.Drawing;
using CPF.Input;
using System;
using System.Collections.Generic;
using System.Text;

namespace 蓝图重制版.BluePrint.Node
{
    public class TextJoint : IJoinControl
    {
        public TextJoint(BParent _bParent, NodePosition JoinDir):base(_bParent){
            nodePosition = JoinDir;
        }

        public NodePosition nodePosition;
        public override void SetDir(NodePosition value)
        {
            nodePosition = value;
        }
        public override NodePosition GetDir()
        {
            return nodePosition;
        }
        public override void Set(object value)
        {
            text1.Text = value.ToString();
        }
        public override object Get()
        {
            return text1.Text;
        }
        public TextBlock text1 = new TextBlock
        {
            Text = "文本a11111111",
            Foreground = Color.FromRgb(255, 255, 255),
            Width = 100,
        };
        /*protected override void Initial0izeComponent()
        {
            Children.Add(new Border { 
                MarginLeft = 0,
                MarginTop = "auto",
                Width = 10,
                Height = 10,
                BorderType = BorderType.BorderThickness,
                BorderThickness = new Thickness(1,1, 1, 1),
                BorderFill = "red",
                Padding = "10,10,10,10",
            });
           
            //Background = Color.FromRgb(81, 137, 255);
        }*/
        protected override void InitializeComponent()
        {
            base.InitializeComponent();
            base.AddControl(text1);
        }
    }
}
