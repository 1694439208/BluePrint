﻿using CPF.Input;
using System;
using System.Collections.Generic;
using System.Text;

namespace 蓝图重制版.BluePrint.Node
{
    class MouseJoin : IJoinControl
    {
        public MouseJoin(BParent _bParent, NodePosition JoinDir) : base(_bParent)
        {
            nodePosition = JoinDir;
        }

        public NodePosition nodePosition;

        protected override void OnMouseDown(MouseButtonEventArgs e)
        {
        }
        protected override void InitializeComponent() { 
        
        }
        public override void SetDir(NodePosition value)
        {
            nodePosition = value;
        }
        public override NodePosition GetDir()
        {
            return nodePosition;
        }
        public override void Set(object value)
        {
            
        }
        public override object Get()
        {
            return "MouseJoin";
        }
    }
}
