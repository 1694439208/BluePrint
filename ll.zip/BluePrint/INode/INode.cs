﻿using CPF.Controls;
using System;
using System.Collections.Generic;
using System.Text;

namespace 蓝图重制版.BluePrint.INode
{
    public class INode
    {
        public DateTime When { get; set; }

    }
    /*class INode<T> : NodeContext where T : Control
    {
        public string Who { get; set; }
        public T NewState;
        public T OldState;
    }*/
}
