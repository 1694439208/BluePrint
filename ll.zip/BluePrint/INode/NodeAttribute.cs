﻿using System;
using System.Collections.Generic;
using System.Text;
using CPF;

namespace 蓝图重制版.BluePrint.INode
{
    [AttributeUsage(AttributeTargets.Class)]
    class NodeClassAttribute : Attribute
    {
        /// <summary>
        /// Name of the node that will be displayed in the node caption.
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 属性设置
        /// </summary>
        /// <param name="name">节点名称</param>
        /// <param name="isCallableInt">节点是否有执行输入</param>
        /// <param name="isCallableOnt">节点是否有执行输出</param>
        public NodeClassAttribute(string name = "Node")
        {
            Name = name;
        }
    }
    [AttributeUsage(AttributeTargets.Method)]
    class NodeAttribute : Attribute
    {
        /// <summary>
        /// Name of the node that will be displayed in the node caption.
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// Width of single node
        /// </summary>
        public bool isCallableInt_ { get; set; }

        /// <summary>
        /// Height of single node
        /// </summary>
        public bool isCallableOnt_ { get; set; }
        /// <summary>
        /// 属性设置
        /// </summary>
        /// <param name="name">节点名称</param>
        /// <param name="isCallableInt">节点是否有执行输入</param>
        /// <param name="isCallableOnt">节点是否有执行输出</param>
        public NodeAttribute(string name = "Node", bool isCallableInt = true, bool isCallableOnt = true)
        {
            Name = name;
            isCallableInt_ = isCallableInt;
            isCallableOnt_ = isCallableOnt;
        }
    }
}
