﻿using CPF;
using CPF.Controls;
using CPF.Drawing;
using CPF.Input;
using System;
using System.Collections.Generic;

using 蓝图重制版.BluePrint.Node;

namespace 蓝图重制版.BluePrint.INode
{
    [NodeClass("字符串拼接")]
    class NodeContext: Control,Context
    {
        public NodeContext(BParent _bParent) {
            bParent = _bParent;
        }
        BParent bParent;
        Dictionary<string, IJoinControl> _IntPutJoin;
        Dictionary<string, IJoinControl> Context.IntPutJoin { 
            get{
                return _IntPutJoin;
            }
            set {
                value = _IntPutJoin;
            }
        }
        Dictionary<string, IJoinControl> _OutPutJoin;
        Dictionary<string, IJoinControl> Context.OutPutJoin {
            get {
                return _OutPutJoin;
            }
            set
            {
                value = _OutPutJoin;
            }
        }

        /// <summary>
        /// 计算节点
        /// </summary>
        public void Execute()
        {
            //取参数 取当前参数对应的接口数据
            /*if (IntPut["时间"].GetStarJoin() is BP_IJoin a)
            {
                var ret = a.Get();
            }
            //OutPut[""].Get<string>();
            foreach (var item in NodeChild)
            {
                item.Execute();
            }*/
        }

        protected override void InitializeComponent()
        {
            ClipToBounds = true;
            this.CornerRadius = "3.8";
            Background = Color.FromRgb(35, 38, 35);
            BorderFill = "#000";
            BorderStroke = "1";

            _OutPutJoin = new Dictionary<string, IJoinControl>
            {
                {"      ->",new TextJoint(bParent,IJoinControl.NodePosition.right){ MarginRight = ActualOffset.X + ActualSize.Width,Width = 35}},
                {"时间戳11111",new TextJoint(bParent,IJoinControl.NodePosition.right){ MarginRight = ActualOffset.X + ActualSize.Width,Width = 35}},
            };

            _IntPutJoin = new Dictionary<string, IJoinControl>
            {
                {"->",new TextJoint(bParent,IJoinControl.NodePosition.Left){ MarginLeft = 0f,Width = 35}},
                {"时间",new TextJoint(bParent,IJoinControl.NodePosition.Left){ MarginLeft = 0f,Width = 35}},

            };

            RefreshNodes();
        }
        public List<IJoinControl> OuPutIJoin = new List<IJoinControl>();
        public List<IJoinControl> InPutIJoin = new List<IJoinControl>();


        int interval = 20;//接口的间隔y坐标
        protected override void OnGotFocus(GotFocusEventArgs e)
        {
            //base.OnGotFocus(e);
            BorderFill = Color.FromRgb(197, 131, 35);
            BorderStroke = "1";
        }
        protected override void OnLostFocus(RoutedEventArgs e)
        {
            //base.OnLostFocus(e);
            BorderFill = Color.FromRgb(35, 38, 35);
            BorderStroke = "1";
        }
        protected override void OnLayoutUpdated()
        {
            base.OnLayoutUpdated();
            //IsKeyboardFocusWithin
        }
        public void RefreshNodes()
        {
            Children.Add(new Title
            {
                IsAntiAlias = true,
                Width = "100%",
                Height = TitleHeight,
                MarginLeft = 0,
                MarginTop = 0,
            });
            foreach (var item in _IntPutJoin)
            {
                item.Value.Set(item.Key);
                AddIJoin(NodePosition.Left, (item.Value as Control));
            }
            foreach (var item in _OutPutJoin)
            {
                item.Value.Set(item.Key);
                AddIJoin(NodePosition.right, (item.Value as Control));
            }
            //

        }

        int TitleHeight = 25;
        public void AddIJoin(NodePosition nodePosition, Control bP_IJoin)
        {
            Children.Add(bP_IJoin);//左边
            if (nodePosition == NodePosition.Left)
            {
                InPutIJoin.Add(bP_IJoin as IJoinControl);
            }
            else
            {
                OuPutIJoin.Add(bP_IJoin as IJoinControl);
            }


            var size = GetHeights();
            Width = size.Width;
            Height = size.Height + TitleHeight;
            float Outheight = TitleHeight;
            float Inheight = TitleHeight;
            int i = 0;
            while (true)
            {
                if (InPutIJoin.Count > i)
                {
                    var col = InPutIJoin[i].GetThis();
                    col.MarginLeft = 1;
                    col.MarginTop = Inheight + (i == 0 ? 16 : interval);
                    Inheight += (i == 0 ? 16 : interval) + col.ActualSize.Height;
                }
                if (OuPutIJoin.Count > i)
                {
                    var col = OuPutIJoin[i].GetThis();
                    col.MarginRight = ActualSize.Width;
                    col.MarginTop = Outheight + (i == 0 ? 16 : interval);
                    Outheight += (i == 0 ? 16 : interval) + col.ActualSize.Height;
                }
                if (OuPutIJoin.Count <= i && InPutIJoin.Count <= i)
                {
                    return;
                }
                i++;
            }
        }
        public Size GetHeights()
        {
            int i = 0;
            float ret1 = 0;
            float ret2 = 0;

            float retw1 = 0;
            float retw2 = 0;

            while (true)
            {
                if (InPutIJoin.Count > i)
                {
                    var col = InPutIJoin[i].GetThis();
                    ret1 += interval + col.ActualSize.Height;
                    retw1 = col.Width.Value > retw1 ? col.Width.Value : retw1;
                }
                if (OuPutIJoin.Count > i)
                {
                    var col = OuPutIJoin[i].GetThis();
                    ret2 += interval + col.ActualSize.Height;
                    retw2 = col.Width.Value > retw2 ? col.Width.Value : retw2;
                }
                if (OuPutIJoin.Count <= i && InPutIJoin.Count <= i)
                {
                    return new CPF.Drawing.Size(retw1 + retw2 + interval, (ret1 > ret2 ? ret1 : ret2) + interval);
                }
                i++;
            }
        }
        [PropertyChanged(nameof(IsKeyboardFocusWithin))]
        void OnIsKeyboardFocusWithin(object newValue, object oldValue, PropertyMetadataAttribute attribute)
        {
            /*if ((bool)newValue)
            {
                BorderFill = Color.FromRgb(197, 131, 35);
                BorderStroke = "1";
            }
            else {
                BorderFill = Color.FromRgb(35, 38, 35);
                BorderStroke = "1";
            }
            */
        }
        protected override void OnMouseDown(MouseButtonEventArgs e)
        {
            base.OnMouseDown(e);
            if (e.MouseButton == MouseButton.Left)
            {
                if (!IsKeyboardFocusWithin)
                {
                    Focus(NavigationMethod.Click);
                }
                
                Mouxy = e.Location;
                isclick = true;
                (Parent as BluePrint).SelectThisInstance(this);
                CaptureMouse();
                //ZIndex = Parent.GetChildren();
            }
            
        }
        protected override void OnMouseUp(MouseButtonEventArgs e)
        {
            base.OnMouseUp(e);
            if (e.LeftButton == MouseButtonState.Released)
            {
                isclick = false;
                ReleaseMouseCapture();
            }
        }
        private Point Mouxy;
        private bool isclick = false;
        protected override void OnMouseMove(MouseEventArgs e)
        {
            //e.Handled = true;
            if (e.LeftButton == MouseButtonState.Pressed && isclick)
            {
                //为了刷新溢出了的线条
                Parent.Parent.Invalidate();
                var a = e.Location - Mouxy;
                MarginLeft += a.X;
                MarginTop += a.Y;
                // TransformPoint
            }
            base.OnMouseMove(e);
            
        }
        ///// <summary>
        ///// 背景填充
        ///// </summary>
        //[UIPropertyMetadata(null, UIPropertyOptions.AffectsRender)]//属性变化之后自动刷新
        //public ViewFill Background
        //{
        //    get { return (ViewFill)GetValue(); }
        //    set { SetValue(value); }
        //}
        public enum NodePosition
        {
            Left, right
        }
        //public delegate void ExecuteHandler(string NameId);
        // 基于上面的委托定义事件
        //public event ExecuteHandler ExecuteHandle;
    }
}
