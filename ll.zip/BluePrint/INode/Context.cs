﻿using System;
using System.Collections.Generic;
using System.Text;
using 蓝图重制版.BluePrint.Node;

namespace 蓝图重制版.BluePrint.INode
{
    public interface Context
    {
        /// <summary>
        /// 用于节点定义输入接口
        /// </summary>
        Dictionary<string, IJoinControl> IntPutJoin { set; get; }
        /// <summary>
        /// 用于节点定义输出接口
        /// </summary>
        Dictionary<string, IJoinControl> OutPutJoin { set; get; }
        void Execute();

 
    }
}
