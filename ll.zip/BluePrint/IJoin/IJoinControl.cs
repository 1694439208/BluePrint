﻿using CPF;
using CPF.Controls;
using CPF.Drawing;
using CPF.Input;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace 蓝图重制版.BluePrint.Node
{
    public class IJoinControl : Control,BP_IJoin
    {
        /// <summary>
        /// 设置接口方向
        /// </summary>
        /// <param name="position"></param>
        public virtual void SetDir(NodePosition position) { }
        /// <summary>
        /// 获取接口方向，默认左边
        /// </summary>
        /// <returns></returns>
        public virtual NodePosition GetDir() { return NodePosition.Left; }
        public enum NodePosition
        {
            Left, right
        };

        public IJoinControl(BParent _bParent) {
            bParent = _bParent;
        }
        BParent bParent;
        protected override void OnMouseDown(MouseButtonEventArgs e)
        {
            base.OnMouseDown(e);
            e.Handled = true;
        }
        public virtual void Set(object value) { }
        public virtual object Get() { return null; }

        public UIElement GetParnt()
        {
            return Parent;
        }
        public delegate void JoinClick(IJoinControl joinControl, MouseButtonEventArgs eventArgs);
        // 基于上面的委托定义事件
        public event JoinClick JoinClickEve;
        public Point GetPos(bool IsZ)
        {
            if (IsZ)
            {
                return TransformPoint(new Point(0,ActualSize.Height / 2));
            }
            return TransformPoint(new Point(ActualSize.Width, ActualSize.Height / 2));
        }

        public Control GetThis()
        {
            return this;
        }
        FloatField Interface_size = 10;
        FloatField Interface_top = "auto";
        protected override void InitializeComponent()
        {
            Children.Add(new Border { 
                MarginLeft = 0,
                MarginTop = Interface_top,
                Width = Interface_size,
                Height = Interface_size,
                BorderType = BorderType.BorderThickness,
                BorderThickness = new Thickness(1,1, 1, 1),
                BorderFill = "red",
                Padding = "10,10,10,10",
                Commands =
                {
                    {
                        nameof(MouseDown),
                        (s,e)=>{
                            (s as Border).BorderFill = "#d4d4d4";
                            (s as Border).CaptureMouse();
                        }
                    },
                    {
                        nameof(MouseUp),
                        (s,e)=>{
                            (s as Border).BorderFill = "red";
                            (s as Border).ReleaseMouseCapture();
                            bParent.SetMouseState(this);
                            Debug.WriteLine("抬起鼠标");
                        }
                    }
                },
            });
            //Background = Color.FromRgb(81, 137, 255);
        }
        public void AddControl(UIElement control) {
            control.MarginLeft = Interface_size + 5;
            control.MarginTop = Interface_top;
            Children.Add(control);
        }
    }
}
