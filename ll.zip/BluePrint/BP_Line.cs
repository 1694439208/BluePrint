﻿using CPF;
using CPF.Controls;
using CPF.Drawing;
using CPF.Input;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using 蓝图重制版.BluePrint.Node;

namespace 蓝图重制版.BluePrint
{
    public class BP_Line : Control
    {
        protected override void OnRender(DrawingContext dc)
        {
            dc.AntialiasMode = AntialiasMode.AntiAlias;
            if (IsSX)//上
            {
                if (IsZ)//左
                {
                    geometry = DrawBezier(new Point(0, 0), new Point(ActualSize.Width, ActualSize.Height));
                }
                else
                {//右
                    geometry = DrawBezier(new Point(ActualSize.Width, 0), new Point(0, ActualSize.Height));
                }
            }
            else
            {
                if (IsZ)
                {
                    geometry = DrawBezier(new Point(0, ActualSize.Height), new Point(ActualSize.Width, 0));
                }
                else
                {
                    geometry = DrawBezier(new Point(ActualSize.Width, ActualSize.Height), new Point(0, 0));
                }

            }
            dc.DrawPath(backound_color, new Stroke(2), geometry);
            VisualClip = new Geometry(geometry);
            //自动计算自己位置
            PositionReckon();
        }
        protected override void InitializeComponent()
        {
            Width = 1;
            Height = 1;
        }
        void PositionReckon()
        {
            if (_Star != null && _End != null)
            {
                var Spos = _Star.GetParnt().TransformPoint(_Star.GetPos(false));
                var SEnd = _End.GetParnt().TransformPoint(_End.GetPos(true));
                if (Spos.X < SEnd.X)
                {
                    Width = SEnd.X - Spos.X;
                    MarginLeft = Spos.X;
                    IsZ = true;
                }
                else if (Spos.X > SEnd.X)
                {
                    Width = Spos.X - SEnd.X;
                    MarginLeft = SEnd.X;
                    IsZ = false;
                }
                if (Spos.Y < SEnd.Y)
                {
                    Height = SEnd.Y - Spos.Y;
                    MarginTop = Spos.Y;
                    IsSX = true;
                }
                else if (Spos.Y > SEnd.Y)
                {
                    Height = Spos.Y - SEnd.Y;
                    MarginTop = SEnd.Y;
                    IsSX = false;
                }
                else
                {//==
                    Height = Spos.Y - SEnd.Y;
                    MarginTop = SEnd.Y;
                    IsSX = false;
                }
            }
        }
        private IJoinControl _Star = null;
        private IJoinControl _End = null;
        private PathGeometry geometry;
        public void SetJoin(IJoinControl a, IJoinControl b)
        {
            _Star = a;
            _End = b;
            //return this;//
        }
        public void SetJoin(Control a, Control b)
        {
            _Star = a as IJoinControl;
            _End = b as IJoinControl;
            // return this;//Control
        }

        public BP_IJoin GetStarJoin() {
            return _Star;
        }
        public BP_IJoin GetEndJoin()
        {
            return _End;
        }
        public void SetStarJoin(IJoinControl value)
        {
            _Star = value;
        }
        public void SetEndJoin(IJoinControl value)
        {
            _End = value;
        }
        public bool IsSX = true;
        public bool IsZ = true;
        /// <summary>
        /// 线段颜色
        /// </summary>
        [UIPropertyMetadata(null, UIPropertyOptions.AffectsRender)]//属性变化之后自动刷新
        public Brush backound_color
        {
            get { return null != (Brush)GetValue() ? (Brush)GetValue() : Brush.Parse("#9ce22d"); }
            set { SetValue(value); }
        }
        protected override void OnMouseEnter(MouseEventArgs e)
        {
            //Debug.Print("进入");
            backound_color = Brush.Parse("#74daf9");
            base.OnMouseEnter(e);
        }
        protected override void OnMouseLeave(MouseEventArgs e)
        {
            //Debug.Print("离开");
            backound_color = Brush.Parse("#9ce22d");
            base.OnMouseLeave(e);
        }
        /// <summary>
        /// 计算两点之间长度
        /// </summary>
        /// <param name="p1"></param>
        /// <param name="p2"></param>
        /// <returns></returns>
        public float Distance(Point p1, Point p2)
        {
            //C# code
            float width = p2.X - p1.X;
            float height = p2.Y - p1.Y;
            float result = (width * width) + (height * height);
            return (float)Math.Sqrt(result);//根号
        }
        /// <summary>
        /// 绘制线条
        /// </summary>
        /// <param name="kCanvas">画布</param>
        /// <param name="cubicTopoint">起始点坐标</param>
        /// <param name="Mousepoint">结束点坐标</param>
        public PathGeometry DrawBezier(Point cubicTopoint,
            Point Mousepoint)
        {
            List<Point> sKPoints = new List<Point>();

            sKPoints.Add(new Point(Mousepoint.X, Mousepoint.Y));
            sKPoints.Add(new Point(cubicTopoint.X, cubicTopoint.Y));

            sKPoints.Add(new Point(50, cubicTopoint.Y));//控制点
            sKPoints.Add(new Point(50, cubicTopoint.Y));//控制点
            //paint1.AddPoly(sKPoints.ToArray());


            float wid = Mousepoint.X - cubicTopoint.X;


            float yiban = Distance(cubicTopoint, Mousepoint) / 3;
            if (Mousepoint.Y < cubicTopoint.Y)
            {
                float hei = cubicTopoint.Y - Mousepoint.Y;
                sKPoints[2] = new Point(cubicTopoint.X + yiban, cubicTopoint.Y);
                sKPoints[3] = new Point(Mousepoint.X - yiban, Mousepoint.Y);
            }
            else
            {
                float hei = Mousepoint.Y - cubicTopoint.Y;
                sKPoints[2] = new Point(cubicTopoint.X + yiban, cubicTopoint.Y);
                sKPoints[3] = new Point(Mousepoint.X - yiban, cubicTopoint.Y + hei);
            }

            //path1.MoveTo(sKPoints[1]);
            //path1.CubicTo(sKPoints[2], sKPoints[3], sKPoints[0]);
            //path1.QuadTo(sKPoints[2], sKPoints[0]);
            //kCanvas.DrawPath(path1, paint1);


            var p = new PathGeometry();


            p.BeginFigure(sKPoints[1].X, sKPoints[1].Y);
            p.CubicTo(sKPoints[2], sKPoints[3], sKPoints[0]);
            return p;
        }
    }
}
